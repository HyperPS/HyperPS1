package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

// Cookie represents a stolen cookie structure
type Cookie struct {
	Name     string `json:"name"`
	Value    string `json:"value"`
	Domain   string `json:"domain"`
	Path     string `json:"path"`
	Expires  int64  `json:"expires"`
	Secure   bool   `json:"secure"`
	HttpOnly bool   `json:"httpOnly"`
}

// ChromeProcess represents Chrome process information
type ChromeProcess struct {
	PID  int
	Name string
}

func main() {
	fmt.Println("Chrome Cookie Memory Extractor Demo")
	fmt.Println("----------------------------------")
	fmt.Println("This demonstrates how cookies can be extracted from Chrome's memory")
	fmt.Println("")

	// Find Chrome processes
	processes, err := findChromeProcesses()
	if err != nil {
		log.Fatalf("Error finding Chrome processes: %v", err)
	}

	if len(processes) == 0 {
		log.Fatal("No Chrome processes found")
	}

	fmt.Println("Found Chrome processes:")
	for _, p := range processes {
		fmt.Printf("- PID: %d, Name: %s\n", p.PID, p.Name)
	}

	// Simulate memory scanning (actual memory scanning would require more privileges)
	fmt.Println("\nSimulating memory scan for decrypted cookies...")

	// Mock finding cookies in memory
	cookies := scanMemoryForCookies(processes[0].PID)
	if len(cookies) == 0 {
		fmt.Println("No cookies found in memory (simulation)")
		return
	}

	// Save cookies to file
	err = saveCookiesToFile(cookies, "cookies_dump.json")
	if err != nil {
		log.Fatalf("Error saving cookies: %v", err)
	}

	fmt.Printf("\nSuccessfully extracted %d cookies to cookies_dump.json\n", len(cookies))
	fmt.Println("This demonstrates how attackers can steal cookies from memory.")
}

func findChromeProcesses() ([]ChromeProcess, error) {
	var processes []ChromeProcess

	switch runtime.GOOS {
	case "windows":
		cmd := exec.Command("tasklist", "/FI", "IMAGENAME eq chrome.exe", "/FO", "CSV", "/NH")
		output, err := cmd.Output()
		if err != nil {
			return nil, err
		}

		lines := strings.Split(string(output), "\n")
		for _, line := range lines {
			parts := strings.Split(line, ",")
			if len(parts) >= 2 {
				name := strings.Trim(parts[0], `"`)
				pid := strings.Trim(parts[1], `" `)
				if name == "chrome.exe" && pid != "" {
					var p ChromeProcess
					fmt.Sscanf(pid, "%d", &p.PID)
					p.Name = name
					processes = append(processes, p)
				}
			}
		}

	case "darwin":
		cmd := exec.Command("pgrep", "-l", "Google Chrome")
		output, err := cmd.Output()
		if err != nil {
			return nil, err
		}

		lines := strings.Split(string(output), "\n")
		for _, line := range lines {
			parts := strings.Fields(line)
			if len(parts) >= 2 && strings.Contains(parts[1], "Google Chrome") {
				var p ChromeProcess
				fmt.Sscanf(parts[0], "%d", &p.PID)
				p.Name = parts[1]
				processes = append(processes, p)
			}
		}

	case "linux":
		cmd := exec.Command("pgrep", "-l", "chrome")
		output, err := cmd.Output()
		if err != nil {
			return nil, err
		}

		lines := strings.Split(string(output), "\n")
		for _, line := range lines {
			parts := strings.Fields(line)
			if len(parts) >= 2 && strings.Contains(parts[1], "chrome") {
				var p ChromeProcess
				fmt.Sscanf(parts[0], "%d", &p.PID)
				p.Name = parts[1]
				processes = append(processes, p)
			}
		}
	}

	return processes, nil
}

func scanMemoryForCookies(pid int) []Cookie {
	// In a real attack, this would use process memory scanning APIs
	// For demo purposes, we return mock data

	return []Cookie{
		{
			Name:     "session_id",
			Value:    "abc123xyz456",
			Domain:   ".example.com",
			Path:     "/",
			Expires:  1735689600,
			Secure:   true,
			HttpOnly: true,
		},
		{
			Name:     "user_prefs",
			Value:    "dark_mode=true",
			Domain:   ".example.com",
			Path:     "/settings",
			Expires:  1735689600,
			Secure:   false,
			HttpOnly: false,
		},
	}
}

func saveCookiesToFile(cookies []Cookie, filename string) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	return encoder.Encode(cookies)
}

// Windows-specific memory reading functions (not used in this demo)
type windowsProcess struct {
	ProcessID       int
	ParentProcessID int
	Exe             string
}

func readProcessMemory(pid int) ([]byte, error) {
	// This would require Windows API calls in a real implementation
	// For demo purposes, we're not actually reading memory
	return nil, fmt.Errorf("memory reading not implemented in this demo")
}
